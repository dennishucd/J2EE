#deployment
mvn assembly:assembly

#run
java -jar quartzexample-1.0.0-SNAPSHOT.jar
